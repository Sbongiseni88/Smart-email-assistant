package com.email.smart_email_assistant_sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartEmailAssistantSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartEmailAssistantSbApplication.class, args);
	}

}
